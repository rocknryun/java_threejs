function togglePopup(){
    document.getElementById("about-col").classList.toggle("active");
}