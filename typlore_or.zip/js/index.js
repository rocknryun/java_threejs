const formWrapper = document.querySelector(".form-wrapper");
const viewContainer = document.querySelector(".view-container");
const sendOpener = document.querySelector(".send-opener");
const formPaper = formWrapper.querySelector(".paper-content");
const submitBtn = document.querySelector("#send");
console.log(submitBtn)
const successContainer = document.querySelector(".success-container")


const closeClass = (className) => {
    className.classList.remove("on");
}

const openClass = (className) => {
    className.classList.add("on");
}

const index_init = () => {
    formWrapper.addEventListener("click", () => {
        closeClass(formWrapper);
    });
    viewContainer.addEventListener("click", () => {
        closeClass(viewContainer);
    });
    sendOpener.addEventListener("click", () => {
        openClass(formWrapper);
    })

    formPaper.addEventListener("click", (e) => {
        e.stopPropagation();

    })

    submitBtn.addEventListener("click", (e) => {
        e.preventDefault();

        openClass(successContainer);
        setTimeout(() => {
            successContainer.style.opacity = 0;
            setTimeout(() => {
                closeClass(successContainer);
                closeClass(formWrapper);
            }, 250)
        }, 1000)
    })
}

index_init();