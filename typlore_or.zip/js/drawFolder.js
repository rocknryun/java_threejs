{/* <div class="folder-wrap">
<div class="folder-inner"></div>
<p class="folder-index">A -</p>
<div class="paper-wrap">
    <div class="paper"></div>
</div>
<div class="folder-outer"></div>
</div> */}

const container = document.querySelector(".container");
const colors = ["red", "orange", "pink", "green", "turquoise", "blue", "indigo", "purple"];
const rooms = ["Family", "Friends", "❤️", "Work", "School", "Human", "Me", "Etc"]

const drawFolder = (color, text, width) => {
    const wrap = document.createElement("div"),
        inner = document.createElement("div"),
        outer = document.createElement("div"),
        paperWrap = document.createElement("div"),
        paper = document.createElement("div");
    const folderLabel = document.createElement("p");

    wrap.className = "folder-wrap";
    inner.className = `folder-inner ${color}`;
    folderLabel.className = "folder-index";
    paperWrap.className = "paper-wrap";
    paper.className = "paper";
    outer.className = `folder-outer ${color}`;

    folderLabel.innerHTML = text;

    paperWrap.appendChild(paper);
    wrap.appendChild(inner);
    wrap.appendChild(folderLabel);
    wrap.appendChild(paperWrap);
    wrap.appendChild(outer);

    container.appendChild(wrap);

    wrap.style.width = `${width}px`;
    const pos = getRandomPosition(document.body, width, width * 0.79);
    wrap.style.top = `${pos.top}px`;
    wrap.style.left = `${pos.left}px`;
}

function getRandomFloor(max, min) {
    return Math.floor(Math.random() * (max - min) + min);
}

function getRandomPosition(parent, elWidth, elHeight) {
    var maxPositionX = window.innerWidth - elWidth;
    var maxPositionY = window.innerHeight - elHeight;
    var randPositionX = getRandomFloor(maxPositionX, 20);
    var randPositionY = getRandomFloor(maxPositionY, 0);
    // 최소 상수값은 마진에 맞게 변경

    return {
        left: randPositionX,
        right: randPositionX + elWidth,
        top: maxPositionY - randPositionY,
        bottom: maxPositionY - randPositionY + elHeight
    }
}

for (let i = 0; i < rooms.length; i++) {
    var randSizeX = getRandomFloor(433, 200);
    drawFolder(colors[i], rooms[i], randSizeX);
}

const folders = document.querySelectorAll(".folder-wrap");
folders.forEach((el) => {
    el.addEventListener("click", () => { document.querySelector(".view-container").classList.add("on") })
})